<?php $__env->startSection('title'); ?>
  <?php echo e($title); ?>

  <div class="pull-right">
      <?php if(\Route::has(strstr(\Route::currentRouteName(),'.',true).'.create')): ?>
        <a href="<?php echo e(route(strstr(\Route::currentRouteName(),'.',true).'.create')); ?>" class="btn btn-primary btn-sm">Add +</a>
      <?php endif; ?>
      <a href="<?php echo e(url()->previous()); ?>" class="btn btn-primary btn-sm">Back</a>
  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

  
      <?php if($data->count() != 0): ?>
        <table class="table table-striped table-hover">
            <thead>
                <tr>
                    <?php $__currentLoopData = $data[0]->toArray(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <th><?php echo e($key); ?></th>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <th>Manage</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <?php $__currentLoopData = $record->toArray(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <td><?php echo e($element); ?></td>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <td><a href="<?php echo e(route(strstr(\Route::currentRouteName(),'.',true).'.edit',['id'=>$record->id])); ?>" class="btn btn-primary btn-block">Manage</a></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
      <?php else: ?>
        no data available!
      <?php endif; ?>
  

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>