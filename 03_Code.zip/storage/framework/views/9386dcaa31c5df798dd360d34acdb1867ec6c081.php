<?php $__env->startSection('title'); ?>
  <?php echo e($title); ?>

  <div class="pull-right">
      <a href="<?php echo e(url()->previous()); ?>" class="btn btn-primary btn-sm">Back</a>
  </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
  <ul class="list-group">
    <?php $__currentLoopData = $data->toArray(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $infoKey => $info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li class="list-group-item">
          <strong><?php echo e($infoKey); ?>:</strong> <?php echo e($info); ?>

        </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </ul>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>