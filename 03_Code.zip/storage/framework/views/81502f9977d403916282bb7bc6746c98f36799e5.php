<?php $__env->startSection('title'); ?>
  <?php echo e($title); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <form class="form-horizontal" name="createServiceType" action="<?php echo e(route('service-types.store')); ?>" method="post">
        <?php echo e(csrf_field()); ?>

        <div class="form-group" id="titleGroup">
            <label for="title" class="col-md-4 control-label">title</label>

            <div class="col-md-6">
                <input id="title" type="text" class="form-control" name="title" placeholder="Title" autofocus>
            </div>
            <div id="titleMsg"></div>
        </div>

        <div class="form-group">
            <div class="col-md-8 col-md-offset-4">
                <input type="submit" id="submit" class="btn btn-primary" value="Create">
            </div>
        </div>
    </form>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
  <script>
    $(document).ready(function() {
        $('Form[name="createServiceType"]').submit(function(e) {
            if ($('#title').val().length != 0) {
                return;
            }
            $('#titleGroup').addClass('has-error').show();
            $("#titleMsg").html('<span class="help-block"><strong>Title Is Required!</strong></span>').show();
            e.preventDefault();
        });
    });
  </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>